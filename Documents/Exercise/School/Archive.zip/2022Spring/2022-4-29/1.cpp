/***
 * @Author: Zi_Gao
 * @Description: 
 */
#include <cstdio>
#include <cstring>
#include <set>
using namespace std;
//#define file
#define stack_type int
inline int read();
void infixtopostfix(char in[],char out[]);
int countpostfix(char in[]);

const int maxstack = 100100;
struct stack{
	stack_type _null,s[maxstack];
	int top;

	stack(){
		top=0;
		memset(s,0,sizeof(s));		
		memset(s,0,sizeof(_null));
		return;
	}
	
	void push(stack_type in){
		if(top < maxstack){
			s[top] = in;
			++top;
		} 
		return;
	}
	
	void pop(){
		if(top > 0){
			s[top-1]=_null;
			top--;
		}
		return;
	}
	
	stack_type top(){
		if(top>0){
			return s[top-1];
		}else{
			return _null;
		}
	}
	
	bool empty(){
		if(top==0){
			return true;
		}else{
			return false;
		}
	}
	
	int size(){
		return top;
	}
	
	void clear(){
		top=0;
	}
};
int main(){
	#ifdef file
	freopen("rain.in", "r", stdin);
	freopen("rain.out", "w", stdout);
	#endif


	//a*(b*(c+d/e)-f)
	//2*(3*(1+4/2)-1) = 16 
	char infix[100]={0},postfix[100]={0};
	scanf("%s",infix);
	infixtopostfix(infix,postfix);
	printf("%s\n",postfix);
	int cntpostfix=countpostfix(postfix);
	printf("%d",cntpostfix);

	#ifdef file
	fclose(stdin);
	fclose(stdout);
	#endif
    return 0;
}

int countpostfix(char in[]){
	stack s;//���������ջ 
	int ini=0,t;//ini�����±� t��ʱ 
	while(in[ini]!='\0'){
		if('0'<=in[ini]&&'9'>=in[ini]){//������ֱ�Ӵ� 
			s.push(in[ini]-'0');
		}else{//count 
			if(in[ini]=='+'){
				t=s.top();
				s.pop();
				t+=s.top();
			}else if(in[ini]=='-'){
				t=s.top();
				s.pop();
				t=s.top()-t;
			}else if(in[ini]=='*'){
				t=s.top();
				s.pop();
				t*=s.top();
			}else if(in[ini]=='/'){
				t=s.top();
				s.pop();
				t=s.top()/t;
			}
			s.pop();
			s.push(t);
		}
		ini++;
	}
	return s.top();
}

void infixtopostfix(char in[],char out[]){
	stack s;
	char t;
	int ini=0,outi=0;//����ʹ�õ������±� 

	//���ȼ��� 
	int map[256]={0};
	map['+']=1;
	map['-']=1;
	map['*']=2;
	map['/']=2;
	
	
	t=in[ini];
	++ini; 
	while(t!='\0'){
		if(('a'<=t&&'z'>=t)||('0'<=t&&'9'>=t)){//�������ֵ 
			out[outi]=t;
			++outi;
		}else if((t=='(')){//���� 
			s.push(t);//Ĭ�����ȼ���0���ͺ�ˬ 
		}else if(t==')'){//���� 
			while(s.top()!='('){
				out[outi]=s.top();
				++outi;
				s.pop();
			}
			s.pop();
		}else{
			while((!s.empty())&&((map[t]<=map[s.top()]))){//����ջά�� 
				out[outi]=s.top();
				++outi;
				s.pop();
			}
			s.push(t);
		}
			t=in[ini];
			++ini;
	}
	
	
	while(!s.empty()){//���ʣ�µķ��� 
		out[outi]=s.top();
		++outi;
		s.pop();
	}
	
	return;
}

inline int read(){
    int x=0,f=1;char c=getchar();
    while(c<'0'||c>'9')c=='-'?f=-1:f,c=getchar();//?=if,:=else
    while(c>='0'&&c<='9'){
        x=(x<<3)+(x<<1)+(c&15);
        c=getchar();
    }
    return x*f;
}
