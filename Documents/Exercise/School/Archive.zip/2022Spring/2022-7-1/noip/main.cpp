#include <cstdio>
using namespace std;

int main(){
	freopen("name.in","r",stdin);
	freopen("name.out","w",stdout);
	
	
	return 0;
}
