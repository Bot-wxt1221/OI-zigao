#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int main(){
	freopen("phoneline.in","r",stdin);
	freopen("phoneline.out","w",stdout);
	printf("-1");

	return 0;
}
