#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int main(){
	freopen("rescue.in","r",stdin);
	freopen("rescue.out","w",stdout);
	printf("-1");

	return 0;
}
