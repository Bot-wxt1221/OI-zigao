#include <cstdio>
using namespace std;
int main(){
	int a;
	scanf("%d",&a);
	if (a>0)
		printf("yes");
	if (a=0)
		printf("no");
	return 0;
}
