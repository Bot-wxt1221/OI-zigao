#include <cstdio>
#include <iostream>
using namespace std;

const float pi = 3.14;
int main(){
	float r,s;
//	scanf("%f", &r);
	cin >> r;
	s = pi * r * r;
//	printf("%.2f",s);
	cout << s;
	return 0;
}
