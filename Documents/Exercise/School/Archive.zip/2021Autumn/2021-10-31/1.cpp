#include <cstdio>
using namespace std;
int main()
{
	char ch;
	scanf("%d",&ch);
	printf("0x%X",ch);
	return 0;
}
