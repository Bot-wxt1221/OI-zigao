#include <cstdio>
using namespace std;
int main(){
	int c = 1;
	
//	while(true){
//		printf("a");
//	}
	
	while(c <= 100){
		printf("a");
		c++;
	}
	
	return 0;
}
