#include <cstdio>
using namespace std;
int main(){
	int x;

	if(1>2)//if 
		printf("yes");
	else
		printf("no");
	
	printf("\n");
	
	if(1)//0Ϊfalse������Ϊtrue 
		printf("yes");
	else
		printf("no");

	printf("\n");

	if (x=0)//����ʽ���Է���ֵ 
		printf("yes");
	else
		printf("no");
	printf("\n");
	printf("%d", (x == 0)); 

	return 0;
}
