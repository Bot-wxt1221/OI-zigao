#include <cstdio>
#include <iostream>
using namespace std;
int main(){
	for(int i;i<=4;i++){
		if((i!=1)+(i==3)+(i==4)+(i==3)==3){
			
			if(i == 1){
				printf("��");	
			}
			if(i == 2){
				printf("��");
			}
			if(i == 3){
				printf("��");
			}
			if(i == 4){
				printf("��");
			}
			printf("��С͵"); 
		}
	}

	return 0;
}
