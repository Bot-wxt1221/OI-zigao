#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <windows.h>
using namespace std;
int main(){
//	cout << "0";
//	Sleep(1000);
//	system("cls");
//	cout << "1";
//	Sleep(1000);
//	system("cls");
//	cout << "2";
//	Sleep(1000);
//	system("cls");
//	cout << "3";
//	Sleep(1000);
//	system("cls");
//	cout << "4";
//	Sleep(1000);
//	system("cls");
//	cout << "5";

	int i=10;
	while(i>=0){
		cout << i;
		Sleep(1000);
		system("cls");
		i--;
	}
	cout << "boom";
	return 0;
}
