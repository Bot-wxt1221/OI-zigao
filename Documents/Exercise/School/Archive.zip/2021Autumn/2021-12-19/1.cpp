#include <cstdio>
#include <iostream>
using namespace std;
const int SIZE=10;

int main(){
	char a[SIZE]={"aaa"};
//	for(int i=0;i<SIZE;i++){
//		cin >> a[i];
////		scanf("%c",&a[i]);
//	}
//	for(int i=0;i<SIZE;i++){
//		cout << a[i];
////		printf("%c",a[i]);
//	}
//	scanf("%s",a);
	printf("%s",a);

	return 0;
}
