/***
 * @Author: Zi_Gao
 * @Date: 2022-01-24 19:04:38
 * @LastEditTime: 2022-01-24 19:09:42
 * @LastEditors: Zi_Gao
 * @Description: 
 */
#include <cstdio>
int main(){
    freopen("multi.in", "w", stdout);
    unsigned long long n=2000000;
    putchar('1');
    while(n){
        putchar('0');
        n--;
    }
    putchar(' ');
    n=2000000;
        while(n){
        putchar('0');
        n--;
    }
}