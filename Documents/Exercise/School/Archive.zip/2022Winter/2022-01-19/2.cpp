/***
 * @Author: Zi_Gao
 * @Date: 2022-01-19 08:18:22
 * @LastEditTime: 2022-01-19 08:19:45
 * @LastEditors: Zi_Gao
 * @Description: 
 */
#include <cstdio>
#include <iostream>
int main(){
    char weekday[7][11]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
    for (int i = 0; i < 7; i++)
    {
        printf("%s\n",weekday[i]);
        /* code */
    }

	return 0;
}