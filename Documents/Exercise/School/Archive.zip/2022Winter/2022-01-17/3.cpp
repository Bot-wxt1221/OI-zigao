/***
 * @Author: Zi_Gao
 * @Date: 2022-01-17 15:43:35
 * @LastEditTime: 2022-01-17 19:40:12
 * @LastEditors: Zi_Gao
 * @Description: 表达式
 */
// #include <cstdio>
#include <iostream>
using namespace std;
int main(){
     cout << 1;
}
