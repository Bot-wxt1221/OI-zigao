/***
 * @Author: Zi_Gao
 * @Date: 2022-01-21 10:06:41
 * @LastEditTime: 2022-01-21 10:07:41
 * @LastEditors: Zi_Gao
 * @Description: 
 */
#include <iostream>
using namespace std;
int main(){
    int a[5]={0,1,2,3,4};
    int *p = a;
    cout << p[1] << endl;
}