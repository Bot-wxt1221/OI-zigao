/***
 * @Author: Zi_Gao
 * @Date: 2022-01-21 11:17:18
 * @LastEditTime: 2022-01-21 11:19:06
 * @LastEditors: Zi_Gao
 * @Description: 
 */
#include <cstdio>
int main(){
    char* p="hello world";
    for(int i=0;i<11;i++){
        putchar(p[i]);
    }
}