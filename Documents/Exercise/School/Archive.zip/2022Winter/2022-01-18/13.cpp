/***
 * @Author: Zi_Gao
 * @Date: 2022-01-18 19:32:56
 * @LastEditTime: 2022-01-18 19:39:01
 * @LastEditors: Zi_Gao
 * @Description: 
 */
#include <iostream>
using namespace std;
int main(){
    char c;
    while(cin>>c){
        cout << c;
    }
    
	return 0;
}