/***
 * @Author: Zi_Gao
 * @Date: 2022-01-18 08:18:35
 * @LastEditTime: 2022-01-18 08:24:11
 * @LastEditors: Zi_Gao
 * @Description: 
 */
#include <cstdio>
#include <iostream>
using namespace std;
int main(){
    long a;
    a=3;
    cout << (long long)a << endl;
    cout << (int)a << endl;
    cout << (short)a << endl;
    cout << (char)a << endl;

	return 0;
}