/***
 * @Author: Zi_Gao
 * @Date: 2022-01-18 08:37:02
 * @LastEditTime: 2022-01-18 08:37:02
 * @LastEditors: Zi_Gao
 * @Description: 
 */
#include <cstdio>
#include <iostream>
using namespace std;
int main(){
    int a;
    scanf("%d",&a);
    

	return 0;
}