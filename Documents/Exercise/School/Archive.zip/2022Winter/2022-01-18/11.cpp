/***
 * @Author: Zi_Gao
 * @Date: 2022-01-18 08:03:32
 * @LastEditTime: 2022-01-18 16:10:55
 * @LastEditors: Zi_Gao
 * @Description: 
 */
#include <cstdio>
#include <iostream>
using namespace std;
int main(){
    // char a[10]={'a','b','c','d','e'};
    // for(int i=0; i<20; i++){
    //     cout<<a[i]<<endl;
    // }


    // char c[]="abcdefghijklmnopqrstuvwxyz";
    // for(int i=0; i<26; i++){
    //     cout<<c[i]<<endl;
    // }

    // char str[];
    // str="a";

    return 0;
}